//
//  SFCalendarMacros.h
//  SFProjectTemplate
//
//  Created by sessionCh on 2016/12/29.
//  Copyright © 2016年 www.sunfobank.com. All rights reserved.
//

#ifndef SFCalendarMacros_h
#define SFCalendarMacros_h

typedef NS_ENUM(NSInteger, SFCalendarType) {
    SFCalendarTypeUnknown,                  // 未定义
    SFCalendarTypeUp,                       // 上月
    SFCalendarTypeCurrent,                  // 当前月
    SFCalendarTypeDown,                     // 下月
    SFCalendarTypeWeek,                     // 表示星期
    SFCalendarTypeMonth,                    // 表示月份
    SFCalendarTypeItemSlide,                // 表示日期滑动
    SFCalendarTypeTopSlide,                 // 表示头部滑动
};

#endif /* SFCalendarMacros_h */
