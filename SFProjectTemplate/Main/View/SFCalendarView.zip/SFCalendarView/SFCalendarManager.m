//
//  SFCalendarManager.m
//  SFProjectTemplate
//
//  Created by sessionCh on 2016/12/29.
//  Copyright © 2016年 www.sunfobank.com. All rights reserved.
//

#import "SFCalendarManager.h"
#import "NSDate+Extension.h"

@interface SFCalendarManager ()

@property (nonatomic, strong) NSDate *date;

@property (nonatomic, strong) NSArray<SFCalendarModel *> *dataArray;    // 日期数据模型
@property (nonatomic, strong) SFCalendarModel *headerModel;             // 头部数据模型
@property (nonatomic, strong) SFCalendarModel *topModel;                // 顶部数据模型
@property (nonatomic, strong) SFCalendarItemModel *selectedItemModel;   // 当前被选中的日期
@property (nonatomic, strong) SFCalendarItemModel *selectedMonthModel;  // 当前被选中的月份

@property (nonatomic, copy) SFCalendarItemUpdateBlock block;

@end

@implementation SFCalendarManager

+ (instancetype)shareInstance
{
    static id instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
    });
    return instance;
}

- (instancetype)init
{
    if (self = [super init]) {
        
    }
    return self;
}

#pragma mark - Setter/Getter

- (NSDate *)date
{
    if (!_date) {
        _date = [NSDate date];
    }
    return _date;
}

- (NSArray<SFCalendarModel *> *)getCalendarData
{
    return self.dataArray;
}

- (SFCalendarModel *)getWeekdayData
{
    return self.headerModel;
}

- (SFCalendarModel *)getMonthData
{
    return self.topModel;
}

- (NSArray<SFCalendarModel *> *)dataArray
{
    if (!_dataArray) {
        
        NSMutableArray *mDataArray = [NSMutableArray arrayWithCapacity:0];
        
        for (NSInteger i = 0; i < 12; i++) {
            
            NSDate *curDate = [self.date dateAfterMonth:i];         // 当月
            NSDate *upDate = [curDate dateAfterMonth:-1];           // 上月
            
            NSInteger curMonthSize = curDate.daysInMonth;           // 本月天数
            NSInteger upMonthSize = upDate.daysInMonth;             // 上月天数
            // 本月第一天对应的星期
            NSInteger firstWeekMonthIndex = [curDate begindayOfMonth].weekday;
            
            NSMutableArray *mItemArray = [NSMutableArray arrayWithCapacity:0];
            // 设置上月日期
            // 本月第一天如果是周日，默认从第二排开始
            NSInteger upSize = firstWeekMonthIndex == 1 ? 7 : firstWeekMonthIndex - 1;
            
            NSLog(@"---[%ld年%ld月 第一天星期%ld]---", curDate.year, curDate.month, firstWeekMonthIndex - 1);
            
            for (NSInteger j = upSize - 1; j >= 0; j--) {
                
                SFCalendarItemModel *item = [[SFCalendarItemModel alloc] init];
                item.index = i;                 // 设置索引
                item.number = upMonthSize - j;
                item.type = SFCalendarTypeUp;
                [mItemArray addObject:item];
            }

            // 设置当前月日期
            for (NSInteger jj = 0; jj < curMonthSize; jj++) {
                
                SFCalendarItemModel *item = [[SFCalendarItemModel alloc] init];
                item.index = i;                 // 设置索引
                item.number = jj + 1;           // 设置号
                item.type = SFCalendarTypeCurrent;
                
                if (curDate.month == self.date.month &&
                    item.number == self.date.day) {
                    
                    item.isNowDay = YES;
                    self.selectedItemModel = item;
                    self.selectedItemModel.isSelected = YES;
                }
                
                [mItemArray addObject:item];
            }
            
            // 设置下月日期
            NSInteger downSize = 42 - upSize - curMonthSize;      // 剩下天数
            for (NSInteger jjj = 0; jjj < downSize; jjj++) {
                
                SFCalendarItemModel *item = [[SFCalendarItemModel alloc] init];
                item.index = i;                 // 设置索引
                item.number = jjj + 1;
                item.type = SFCalendarTypeDown;
                [mItemArray addObject:item];
            }
            
            SFCalendarModel *model = [[SFCalendarModel alloc] init];
            model.index = i;                                        // 设置索引
            model.number = curDate.month;                           // 设置当前月
            model.dataArray = mItemArray.copy;                      // 设置当月日期
            
            [mDataArray addObject:model];
        }
        
        // 设置数据
        _dataArray = mDataArray.copy;
    }
    return _dataArray;
}

- (SFCalendarModel *)headerModel
{
    if (!_headerModel) {
        _headerModel = [[SFCalendarModel alloc] init];
        
        NSMutableArray *dataArray = [NSMutableArray arrayWithCapacity:0];
        
        NSArray *weekdays = @[@"日", @"一", @"二", @"三", @"四", @"五", @"六"];
        
        for (NSInteger i = 1; i <= 7; i++) {
            SFCalendarItemModel *item = [[SFCalendarItemModel alloc] init];
            item.weekday = weekdays[i - 1];
            item.type = SFCalendarTypeWeek;
            
            [dataArray addObject:item];
        }
        _headerModel.dataArray = dataArray.copy;
    }
    return _headerModel;
}

- (SFCalendarModel *)topModel
{
    if (!_topModel) {
        _topModel = [[SFCalendarModel alloc] init];
        
        NSMutableArray *dataArray = [NSMutableArray arrayWithCapacity:0];
        
    
        for (NSInteger i = 0; i < 12; i++) {
            SFCalendarItemModel *item = [[SFCalendarItemModel alloc] init];
            // 获取下一月
            NSDate *upDate = [self.date dateAfterMonth:i];
            item.index = i;
            item.month = [NSString stringWithFormat:@"%ld月", upDate.month];
            item.year = [NSString stringWithFormat:@"%ld", upDate.year];
            item.type = SFCalendarTypeMonth;
 
            if (i == 0) {
                item.isSelected = YES;
                self.selectedMonthModel = item;
            }
            
            [dataArray addObject:item];
        }
        _topModel.dataArray = dataArray.copy;
    }
    return _topModel;
}

- (SFCalendarItemModel *)getSelectedItemModel
{
    return self.selectedItemModel;
}

- (SFCalendarItemModel *)getSelectedMonthModel
{
    return self.selectedMonthModel;
}

#pragma mark - Update

- (void)updateSelectedMonthIndex:(NSInteger)index
{
    if (index != self.selectedMonthModel.index) {
        
        // 更新数据
        self.selectedMonthModel.isSelected = NO;
        SFCalendarItemModel *item = self.topModel.dataArray[index];
        item.isSelected = YES;
        self.selectedMonthModel = item;
        
        // 通知回调
        if (self.block) {
            self.block(SFCalendarTypeItemSlide);
        }
    }
}

- (void)updateSelectedItemModel:(SFCalendarItemModel *)model
{
    if (model && model != self.selectedItemModel) {
                
        // 如果点击上月或下月图标，滚动到对应页面
        switch (model.type) {
                
            case SFCalendarTypeCurrent:
            {
                SFCalendarItemModel *oldModel = self.selectedItemModel;
                oldModel.isSelected = NO;
                SFCalendarItemModel *newModel = model;
                newModel.isSelected = YES;
                
                self.selectedItemModel = newModel;
                
                if (self.block) {
                    self.block(SFCalendarTypeCurrent);
                }
                
                NSLog(@"---[上次选中：%ld  当前选中：%ld]---", oldModel.number, newModel.number);

                break;
            }
                
            case SFCalendarTypeUp:
            {
                if (model.index > 0) { // 第一个月除外
                    
                    // 获取上月数据
                    SFCalendarModel *upModel = self.dataArray[model.index - 1];
                    WeakSelf
                    [upModel.dataArray enumerateObjectsWithOptions:NSEnumerationReverse usingBlock:^(SFCalendarItemModel * _Nonnull upItem, NSUInteger idx, BOOL * _Nonnull stop) {
                        
                        if (upItem.number == model.number &&
                            upItem.type == SFCalendarTypeCurrent) { // 前一月对应的日期
                            SFCalendarItemModel *oldModel = weakSelf_SC.selectedItemModel;
                            oldModel.isSelected = NO;
                            SFCalendarItemModel *newModel = upItem;
                            newModel.isSelected = YES;
                            
                            weakSelf_SC.selectedItemModel = newModel;
                            
                            if (weakSelf_SC.block) {
                                weakSelf_SC.block(SFCalendarTypeUp);
                            }
                            
                            NSLog(@"---[上次选中：%ld  当前选中：%ld]---", oldModel.number, newModel.number);
                            return ;
                        }
                     }];
                }
                
                break;
            }
                
            case SFCalendarTypeDown:
            {
                if (model.index < 11) { // 最后一个月除外
                    
                    // 获取上月数据
                    SFCalendarModel *downModel = self.dataArray[model.index + 1];
                    WeakSelf
                    [downModel.dataArray enumerateObjectsWithOptions:NSEnumerationConcurrent usingBlock:^(SFCalendarItemModel * _Nonnull downItem, NSUInteger idx, BOOL * _Nonnull stop) {
                        
                        if (downItem.number == model.number &&
                            downItem.type == SFCalendarTypeCurrent) { // 前一月对应的日期
                            SFCalendarItemModel *oldModel = weakSelf_SC.selectedItemModel;
                            oldModel.isSelected = NO;
                            SFCalendarItemModel *newModel = downItem;
                            newModel.isSelected = YES;
                            
                            weakSelf_SC.selectedItemModel = newModel;
                            
                            if (weakSelf_SC.block) {
                                weakSelf_SC.block(SFCalendarTypeDown);
                            }
                            
                            NSLog(@"---[上次选中：%ld  当前选中：%ld]---", oldModel.number, newModel.number);

                            return ;
                        }
                    }];
                }
                break;
            }
               
            case SFCalendarTypeMonth:
            {
                [self updateSelectedMonthIndex:model.index];
                if (self.block) {
                    self.block(SFCalendarTypeMonth);
                }
                NSLog(@"---[当前选中的月份：%@]---", model.month);
            
                break;
            }
                
            default:
                
                NSLog(@"---[上次选中：%ld  当前选中：%ld]---", model.number, self.selectedItemModel.number);
                break;
        }
    }
}

#pragma mark - Block

- (void)itemUpdateBlock:(SFCalendarItemUpdateBlock)block
{
    self.block = block;
}

@end
