//
//  SFCalendarItemCell.h
//  SFProjectTemplate
//
//  Created by sessionCh on 2016/12/29.
//  Copyright © 2016年 www.sunfobank.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SFCalendarItemModel.h"

@interface SFCalendarItemCell : UICollectionViewCell

@property (nonatomic, strong) SFCalendarItemModel *model;

@end
