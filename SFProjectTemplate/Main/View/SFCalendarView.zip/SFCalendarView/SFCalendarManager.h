//
//  SFCalendarManager.h
//  SFProjectTemplate
//
//  Created by sessionCh on 2016/12/29.
//  Copyright © 2016年 www.sunfobank.com. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SFCalendarMacros.h"
#import "SFCalendarModel.h"
#import "SFCalendarItemModel.h"

typedef void (^SFCalendarItemUpdateBlock)(SFCalendarType type); // 数据更新通知

@interface SFCalendarManager : NSObject

+ (instancetype)shareInstance;

- (NSArray<SFCalendarModel *> *)getCalendarData;
- (SFCalendarModel *)getWeekdayData;
- (SFCalendarModel *)getMonthData;
- (SFCalendarItemModel *)getSelectedItemModel;
- (SFCalendarItemModel *)getSelectedMonthModel;

- (void)updateSelectedItemModel:(SFCalendarItemModel *)model;
- (void)updateSelectedMonthIndex:(NSInteger)index;

- (void)itemUpdateBlock:(SFCalendarItemUpdateBlock)block;

@end
