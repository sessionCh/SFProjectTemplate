//
//  SFCalendarItemModel.h
//  SFProjectTemplate
//
//  Created by sessionCh on 2016/12/29.
//  Copyright © 2016年 www.sunfobank.com. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SFCalendarMacros.h"

@interface SFCalendarItemModel : NSObject

@property (nonatomic, strong) NSDate *date;             // 当前日期

@property (nonatomic, assign) BOOL isNowDay;            // 是否当天
@property (nonatomic, assign) BOOL isSelected;          // 是否选中
@property (nonatomic, assign) NSInteger index;          // 索引
@property (nonatomic, assign) NSInteger number;         // 号

@property (nonatomic, copy) NSString *weekday;          // 星期

@property (nonatomic, copy) NSString *month;            // 月份
@property (nonatomic, copy) NSString *year;             // 年份
@property (nonatomic, assign) SFCalendarType type;  // 类型

@end
